#LimitedWord
**This is a word guessing game

    You the player are given a variation of letter combinations that you can use to guess a word with the letter combination given
    in that order.

    You have 3 lives

    You can score up to 8 points each round depending on the length of the word you entered

    After failing 3 times, the game is over and you are told your final score.
